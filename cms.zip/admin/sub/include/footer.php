	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; <?php  $year=date("Y");
echo htmlentities($year);

			?> CMS </b> All rights reserved.
		</div>
	</div>